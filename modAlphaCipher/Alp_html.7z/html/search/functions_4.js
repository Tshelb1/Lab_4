var searchData=
[
  ['modalphacipher_19',['modAlphaCipher',['../classmodAlphaCipher.html#a4f0a86c20f5d836f66cb1e640d875e6b',1,'modAlphaCipher::modAlphaCipher()=delete'],['../classmodAlphaCipher.html#a314fca132f4e74faca280b7c1fad7cb5',1,'modAlphaCipher::modAlphaCipher(const std::wstring &amp;skey)']]]
];
