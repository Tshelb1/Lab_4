var searchData=
[
  ['getvalidkey_5',['getValidKey',['../classmodAlphaCipher.html#a36544c603bcd87edcc33df0c8fa26c9f',1,'modAlphaCipher']]],
  ['getvalidtext_6',['getValidText',['../classmodAlphaCipher.html#a7355f4f2d714446d50f78bf262beff34',1,'modAlphaCipher']]]
];
